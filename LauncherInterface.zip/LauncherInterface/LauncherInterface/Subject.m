//
//  Subject.m
//  LauncherInterface
//
//  Created by Apple on 16/7/4.
//  Copyright © 2016年 MK2. All rights reserved.
//

#import "Subject.h"
#import "ObjectOfSubject.h"
#import "describtionOfSubjectCell.h"

#define cWidthOfScreen [[UIScreen mainScreen] bounds].size.width
#define cHeightOfScreen [[UIScreen mainScreen] bounds].size.width * 9/16

@interface Subject()

@property (nonatomic) UICollectionViewFlowLayout *layout;
@property (nonatomic) NSMutableArray *Subject;

-(void)initLayout;

@end

@implementation Subject 

static NSString * const reuseIdentifier = @"SubjectCell";

#pragma mark 工厂方法
+(Subject *)subject{
    Subject *subject = [[Subject alloc] initFrame];
    return subject;
}

#pragma mark 初始化
-(Subject *)initFrame {
    if (self = [super init]){
    [self initData];
    //加载科目数据
    
    [self initLayout];
    //创建流式布局
        self.collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0,cHeightOfScreen+20,cWidthOfScreen,80) collectionViewLayout:self.layout];
        self.collectionView.backgroundColor = [UIColor whiteColor];
    // Register cell classes
    [self.collectionView registerClass:[describtionOfSubjectCell class] forCellWithReuseIdentifier:reuseIdentifier];
    //注册自定义的collectionViewCell
    
    self.collectionView.dataSource = self;
    self.collectionView.delegate = self;
    //初始化collectionView
    }
    return self;
}

#pragma mark 创建流式布局

-(void)initLayout{
    
    self.layout = [[UICollectionViewFlowLayout alloc]init];
    //初始化流式布局
    
    [self.layout setScrollDirection:UICollectionViewScrollDirectionVertical];
    //设置滚动方向
    
    self.layout.itemSize = CGSizeMake(([[UIScreen mainScreen] bounds].size.width / 4) - 20,50);
}

#pragma mark 加载数据

-(void) initData{
    NSString *SubjectObjectPath = [[NSBundle mainBundle] pathForResource:@"Subject" ofType:@"plist"];
    NSArray *SubjectObjectArray = [NSArray arrayWithContentsOfFile:SubjectObjectPath];
    //根据plist文件，获取科目对象数组
    
    self.Subject = [[NSMutableArray alloc]init];
    [SubjectObjectArray enumerateObjectsUsingBlock:^(NSDictionary *obj, NSUInteger idx, BOOL *stop) {
        [self.Subject addObject:[ObjectOfSubject SubjectWithDictionary:obj]];
    }];
    //遍历科目对象数组，赋给对应的self.Subject
}

#pragma mark <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.Subject.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    describtionOfSubjectCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    //     Configure the cell
    ObjectOfSubject *Subject=self.Subject[indexPath.row];
    cell.Subject = Subject;
    return cell;
}

#pragma mark <UICollectionViewDelegate>

-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndexPath:(NSIndexPath *)indexPath {
    return 10;
}
//设置item间的最小间距

-(CGFloat) collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndexPath:(NSIndexPath *)indexPath {
    return 0;
}
//设置行间距

-(UIEdgeInsets) collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    return UIEdgeInsetsMake(10,10,10,10);
}
//设置缩进

@end
