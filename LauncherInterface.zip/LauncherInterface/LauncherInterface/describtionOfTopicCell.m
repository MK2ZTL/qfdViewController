//
//  describtionOfTopicCellCollectionViewCell.m
//  LauncherInterface
//
//  Created by Apple on 16/6/30.
//  Copyright © 2016年 MK2. All rights reserved.
//

#import "describtionOfTopicCell.h"
#import "Masonry.h"
//导入masonry头文件
#import "ObjectOfTopic.h"
//导入主题对象头文件

#define topicCollectionViewCellBackgroundColor [UIColor whiteColor]
#define topicBlackColor [UIColor blackColor]
#define topicGrayColor [UIColor grayColor]

#define topicBoldFont [UIFont boldSystemFontOfSize:11]
#define topicDefaultFont [UIFont fontWithName:@"ArialMT" size:9]

@implementation describtionOfTopicCell

-(instancetype)initWithFrame:(CGRect) frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self initSubView];
    }
    return self;
}

#pragma mark 初始化视图控件
-(void) initSubView{
    
      self.topicPhoto = [[UIImageView alloc] init];
      self.topicPhoto.contentMode = UIViewContentModeScaleAspectFit;
      [self.contentView addSubview:_topicPhoto];
      //初始化主题图片控件
    
      self.topicDescribtion = [[UILabel alloc]init];
      self.topicDescribtion.textColor = topicBlackColor;
      self.topicDescribtion.font = topicBoldFont;
      self.topicDescribtion.numberOfLines = 0;
      [self.contentView addSubview:self.topicDescribtion];
      //初始化主题描述控件
    
      self.topicSubtitle = [[UILabel alloc]init];
      self.topicSubtitle.textColor = topicGrayColor;
      self.topicSubtitle.font = topicDefaultFont;
      self.topicSubtitle.numberOfLines = 0;
      [self.contentView addSubview:self.topicSubtitle];
      //初始化副标题控件
    
}

-(void) setTopic:(ObjectOfTopic *) topic {
    [self.topicPhoto mas_makeConstraints:^(MASConstraintMaker *make){
        
        make.top.equalTo(self.contentView).with.offset(10);
        make.trailing.equalTo(self.contentView).with.offset(-10);
        
        make.height.equalTo(self.contentView).with.multipliedBy(0.6).offset(0);
        make.width.equalTo(self.topicPhoto.mas_height);
        //设置主题图片布局约束
        self.topicPhoto.image = [UIImage imageNamed:topic.topicPhotoPath];
    }];

    [self.topicDescribtion mas_makeConstraints:^(MASConstraintMaker *make){
        make.top.equalTo(self.contentView).with.offset(10);
        make.leading.equalTo(self.contentView).with.offset(10);
        make.trailing.equalTo(self.topicPhoto.mas_leading).with.offset(-10);
        //设置主题描述标题布局约束
        self.topicDescribtion.text = topic.topicDescribtion;
    }];
    
    [self.topicSubtitle mas_makeConstraints:^(MASConstraintMaker *make){
        make.top.equalTo(self.topicDescribtion.mas_bottom).with.offset(3);
        make.leading.equalTo(self.contentView).with.offset(10);
        make.trailing.equalTo(self.topicPhoto.mas_leading).with.offset(-10);
        //设置副标题布局约束
        self.topicSubtitle.text = topic.topicSubtitle;
    }];
}
@end
