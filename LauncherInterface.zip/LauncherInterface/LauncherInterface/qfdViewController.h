//
//  ViewController.h
//  LauncherInterface
//
//  Created by Apple on 16/7/4.
//  Copyright © 2016年 MK2. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "advertisingPictureLayout.h"
#import "Subject.h"
#import "topics.h"
#import "courses.h"

@interface qfdViewController : UIViewController

@property (nonatomic) UIScrollView *mainScrV;
@property (nonatomic) advertisingPictureLayout *advertice;
//首页上方的翻滚图片
@property (nonatomic) Subject *subject;
//科目视图
@property (nonatomic) topics *topics;
//主题视图
@property (nonatomic) courses *courses;

@end
