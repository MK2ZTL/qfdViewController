//
//  ObjectOfTopic.h
//  LauncherInterface
//
//  Created by Apple on 16/6/30.
//  Copyright © 2016年 MK2. All rights reserved.
//

//通过plist生成主题对象

#import <Foundation/Foundation.h>

@interface ObjectOfTopic : NSObject


#pragma mark - 属性
@property (nonatomic,copy) NSString *topicPhotoPath;
//主题图片的路径
@property (nonatomic,copy) NSString *topicDescribtion;
//主题描述
@property (nonatomic,copy) NSString *topicSubtitle;
//副标题

#pragma mark - 方法
#pragma mark 根据字典初始化主题对象
-(ObjectOfTopic *) initWithDictionary:(NSDictionary *) dic;

#pragma mark - 初始化主题对象（工厂方法）
+(ObjectOfTopic *) topicWithDictionary:(NSDictionary *) dic;

@end
