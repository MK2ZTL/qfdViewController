//
//  ObjectOfTopic.m
//  LauncherInterface
//
//  Created by Apple on 16/6/30.
//  Copyright © 2016年 MK2. All rights reserved.
//

#import "ObjectOfTopic.h"

@implementation ObjectOfTopic

#pragma mark 根据字典初始化主题对象
-(ObjectOfTopic *) initWithDictionary:(NSDictionary *)dic {
    if(self=[super init]){
        self.topicPhotoPath = dic[@"topicPhotoPath"];
        self.topicDescribtion = dic[@"topicDescribtion"];
        self.topicSubtitle = dic[@"topicSubtitle"];
    }
    return self;
}

#pragma mark 初始化课程对象（工厂方法）
+(ObjectOfTopic *) topicWithDictionary:(NSDictionary *)dic {
    ObjectOfTopic *topic = [[ObjectOfTopic alloc] initWithDictionary:dic];
    return topic;
}

@end
