//
//  topics.m
//  LauncherInterface
//
//  Created by Apple on 16/7/4.
//  Copyright © 2016年 MK2. All rights reserved.
//

#import "topics.h"
#import "ObjectOfTopic.h"
#import "describtionOfTopicCell.h"

#define cWidthOfScreen [[UIScreen mainScreen] bounds].size.width
#define cHeightOfScreen [[UIScreen mainScreen] bounds].size.width * 9/16

@interface topics()

@property (nonatomic) UICollectionViewFlowLayout *layout;
@property (nonatomic) NSMutableArray *topic;

-(void)initLayout;

@end

@implementation topics


static NSString * const reuseIdentifier = @"topicCell";

#pragma mark 工厂方法
+(topics *)topics{
    topics *topic = [[topics alloc] initFrame];
    return topic;
}

#pragma mark 初始化
-(topics *)initFrame {
    if (self = [super init]){
        [self initData];
        //加载科目数据
        
        [self initLayout];
        //创建流式布局
        self.collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0,cHeightOfScreen+150,cWidthOfScreen,160) collectionViewLayout:self.layout];
//        self.collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0,cHeightOfScreen+130,cWidthOfScreen,200) collectionViewLayout:self.layout];
        self.collectionView.backgroundColor = [UIColor whiteColor];
        // Register cell classes
        [self.collectionView registerClass:[describtionOfTopicCell class] forCellWithReuseIdentifier:reuseIdentifier];
        //注册自定义的collectionViewCell
        
        self.collectionView.dataSource = self;
        self.collectionView.delegate = self;
        //初始化collectionView
    }
    return self;
}

#pragma mark 创建流式布局

-(void)initLayout{
    
    self.layout = [[UICollectionViewFlowLayout alloc]init];
    //初始化流式布局
    
    [self.layout setScrollDirection:UICollectionViewScrollDirectionVertical];
    //设置滚动方向
    
    self.layout.itemSize = CGSizeMake(([[UIScreen mainScreen] bounds].size.width / 2) - 5,50);
}

#pragma mark 加载数据

-(void) initData{
    NSString *topicObjectPath = [[NSBundle mainBundle] pathForResource:@"topic" ofType:@"plist"];
    NSArray *topicObjectArray = [NSArray arrayWithContentsOfFile:topicObjectPath];
    //根据plist文件，获取主题对象数组
    
    self.topic = [[NSMutableArray alloc]init];
    [topicObjectArray enumerateObjectsUsingBlock:^(NSDictionary *obj, NSUInteger idx, BOOL *stop) {
        [self.topic addObject:[ObjectOfTopic topicWithDictionary:obj]];
    }];
    //遍历主题对象数组，赋给对应的self.topic
}

#pragma mark <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.topic.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    describtionOfTopicCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    //     Configure the cell
    ObjectOfTopic *topic=self.topic[indexPath.row];
    cell.topic = topic;
    return cell;
}

#pragma mark <UICollectionViewDelegate>

-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndexPath:(NSIndexPath *)indexPath {
    return 0;
}
//设置item间的最小间距

-(CGFloat) collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndexPath:(NSIndexPath *)indexPath {
    return 0;
}
//设置行间距

@end
