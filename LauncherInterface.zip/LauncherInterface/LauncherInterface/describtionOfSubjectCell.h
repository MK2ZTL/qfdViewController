//
//  describtionOfSubjectCell.h
//  LauncherInterface
//
//  Created by Apple on 16/7/2.
//  Copyright © 2016年 MK2. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ObjectOfSubject;

@interface describtionOfSubjectCell : UICollectionViewCell

#pragma mark 科目对象
@property (nonatomic,strong) ObjectOfSubject *Subject;

@property (nonatomic) UIImageView *SubjectPhoto;
@property (nonatomic) UILabel *SubjectDescribtion;
//科目表单元格的2个UI对象

@end
