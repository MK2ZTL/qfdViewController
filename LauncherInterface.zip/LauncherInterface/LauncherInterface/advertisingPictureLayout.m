//
//  advertisingPictureLayout.m
//  LauncherInterface
//
//  Created by Apple on 16/7/4.
//  Copyright © 2016年 MK2. All rights reserved.
//
#import "advertisingPictureLayout.h"
#import "masonry.h"

#define cWidthOfScreen [[UIScreen mainScreen] bounds].size.width
#define cHeightOfScreen [[UIScreen mainScreen] bounds].size.width * 9/16
//宏定义屏幕宽高

@interface advertisingPictureLayout ()

@property (nonatomic) UIImageView *imgVLeft;
@property (nonatomic) UIImageView *imgVCenter;
@property (nonatomic) UIImageView *imgVRight;
@property (nonatomic) NSMutableArray *imageDataArray;
@property (nonatomic) NSUInteger currentImageIndex;

-(void)loadImageData;
//加载图片数据

-(void)addScrolView;
//加载滚动视图

-(void)addImageViewsToScrollView;
//添加3个图片视图到滚动视图内

-(void)addPageControl;
//添加分页控件

-(void)setInfoByCurrentImageIndex:(NSUInteger)currentImageIndex;
//根据当前显示图片索引设置信息

-(void)setDefaultInfo;
//设置默认信息

-(void)reloadImage;
//重新加载图片

@end

@implementation advertisingPictureLayout

#pragma mark 工厂方法
+(advertisingPictureLayout *)advertisingPicture {
    advertisingPictureLayout * advertisingPicture = [[advertisingPictureLayout alloc]initFrame];
    return advertisingPicture;
}

#pragma mark 初始化方法
-(advertisingPictureLayout *)initFrame {
    if (self = [super init]) {
        [self loadImageData];
        [self addScrolView];
        [self addImageViewsToScrollView];
        [self addPageControl];
        [self setDefaultInfo];
    }
    return self;
}

#pragma mark 每个方法的具体实现
-(void)loadImageData {
    NSString *advertisingPicturePath = [[NSBundle mainBundle] pathForResource:@"advertisingPicture" ofType:@"plist"];
    self.imageDataArray = [NSMutableArray arrayWithContentsOfFile:advertisingPicturePath];
    self.imageCount = self.imageDataArray.count;
}

-(void)addScrolView {
    self.scrV = [[UIScrollView alloc] initWithFrame:CGRectMake(0,40,cWidthOfScreen,cHeightOfScreen)];
    self.scrV.contentSize = CGSizeMake(cWidthOfScreen * self.imageCount, cHeightOfScreen);
    self.scrV.contentOffset = CGPointMake(cWidthOfScreen,0);
    self.scrV.pagingEnabled = YES;
    self.scrV.showsHorizontalScrollIndicator = NO;
    self.scrV.delegate = self;
}

-(void)addImageViewsToScrollView {
    self.imgVLeft = [[UIImageView alloc] initWithFrame:CGRectMake(0,0,cWidthOfScreen,cHeightOfScreen)];
    self.imgVLeft.contentMode = UIViewContentModeScaleAspectFit;
    [self.scrV addSubview:self.imgVLeft];
    
    //添加左侧图片视图
    
    self.imgVCenter = [[UIImageView alloc] initWithFrame:CGRectMake(cWidthOfScreen,0,cWidthOfScreen,cHeightOfScreen)];
    self.imgVCenter.contentMode = UIViewContentModeScaleAspectFit;
    [self.scrV addSubview:self.imgVCenter];
    //添加中间图片视图
    
    self.imgVRight = [[UIImageView alloc] initWithFrame:CGRectMake(cWidthOfScreen * 2,0,cWidthOfScreen,cHeightOfScreen)];
    self.imgVRight.contentMode = UIViewContentModeScaleAspectFit;
    [self.scrV addSubview:self.imgVRight];
    //添加右侧图片视图
    
    
}

-(void)addPageControl {
    self.pageC = [[UIPageControl alloc] init];
    CGSize PCsize = [self.pageC sizeForNumberOfPages:self.imageCount];

    //根据分页数量返回UIPageControl的合适大小

    self.pageC.bounds = CGRectMake(0,0,PCsize.width,PCsize.height);
    self.pageC.center = CGPointMake(cWidthOfScreen / 2,cHeightOfScreen);
    
    self.pageC.numberOfPages = self.imageCount;
    self.pageC.pageIndicatorTintColor = [UIColor whiteColor];
    self.pageC.currentPageIndicatorTintColor = [UIColor brownColor];
    self.pageC.userInteractionEnabled = NO;
    //设置分页控制器的大小，位置，颜色以及是否可交互
}

-(void) setInfoByCurrentImageIndex:(NSUInteger)currentImageIndex {
    self.imgVCenter.image = [UIImage imageNamed:[NSString stringWithFormat:@"advertising%lu.jpg",(unsigned long)self.currentImageIndex]];
    self.imgVLeft.image = [UIImage imageNamed:[NSString stringWithFormat:@"advertising%lu.jpg",(unsigned long)(self.currentImageIndex - 1 + self.imageCount) % self.imageCount]];
    self.imgVRight.image = [UIImage imageNamed:[NSString stringWithFormat:@"advertising%lu.jpg",(unsigned long)(self.currentImageIndex + 1) % self.imageCount]];
    
    self.pageC.currentPage = self.currentImageIndex;
}

-(void)setDefaultInfo {
    self.currentImageIndex = 0;
    [self setInfoByCurrentImageIndex:self.currentImageIndex];
}

-(void)reloadImage {
    CGPoint contentOffset = self.scrV.contentOffset;
    if (contentOffset.x > cWidthOfScreen) {
        // 向左滑动
        self.currentImageIndex = (self.currentImageIndex + 1) % self.imageCount;
    } else if (contentOffset.x < cWidthOfScreen) {
        //向右滑动
        self.currentImageIndex = (self.currentImageIndex - 1 +self.imageCount) % self.imageCount;
    }
    
    [self setInfoByCurrentImageIndex:self.currentImageIndex];
}

#pragma mark - UIScrollViewDelegate
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    [self reloadImage];
    
    self.scrV.contentOffset = CGPointMake(cWidthOfScreen,0);
    self.pageC.currentPage = self.currentImageIndex;
}

@end
