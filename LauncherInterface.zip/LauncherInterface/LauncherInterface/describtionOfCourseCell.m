//
//  describtionOfCourseCell.m
//  LauncherInterface
//
//  Created by Apple on 16/6/28.
//  Copyright © 2016年 MK2. All rights reserved.
//

#import "describtionOfCourseCell.h"
#import "Masonry.h"
//导入masonry头文件
#import "ObjectOfCourse.h"
//导入课程对象头文件

#define courseTableViewCellBackgroundColor [UIColor whiteColor]
#define courseBlackColor [UIColor blackColor]
#define courseGrayColor [UIColor grayColor]
#define courseGreenColor [UIColor greenColor]

#define courseBoldFont [UIFont boldSystemFontOfSize:13]
#define courseDefaultFont [UIFont fontWithName:@"ArialMT" size:10]
#define coursePriceFont [UIFont fontWithName:@"ArialMT" size:12]

@interface describtionOfCourseCell () {
    
    UIImageView *_coursePhoto;
    UILabel *_courseDescribtion;
    UILabel *_courseTeacher;
    UILabel *_courseDate;
    UILabel *_coursePrice;
    UILabel *_numberOfMembersInCourse;
    //课程表单元格的6个UI对象
    
    UIView *_splitLine;
    //课程老师与日期两个label中间的分割线
}
@end


@implementation describtionOfCourseCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initSubView];
    }
    return self;
}

#pragma mark 初始化视图控件
-(void) initSubView{
    
    _coursePhoto = [[UIImageView alloc] init];
    [self addSubview:_coursePhoto];
    //初始化课程图片控件
    
    _courseDescribtion = [[UILabel alloc]init];
    _courseDescribtion.textColor = courseBlackColor;
    _courseDescribtion.font = courseBoldFont;
    _courseDescribtion.numberOfLines = 0;
    [self addSubview:_courseDescribtion];
    //初始化课程描述控件
    
    _courseTeacher = [[UILabel alloc]init];
    _courseTeacher.textColor = courseGrayColor;
    _courseTeacher.font = courseDefaultFont;
    [self addSubview:_courseTeacher];
    //初始化课程老师控件
    
    _courseDate =[[UILabel alloc]init];
    _courseDate.textColor = courseGrayColor;
    _courseDate.font = courseDefaultFont;
    [self addSubview:_courseDate];
    //初始化上课时间控件
    
    _coursePrice = [[UILabel alloc]init];
    _coursePrice.textColor = courseGreenColor;
    _coursePrice.font = coursePriceFont;
    [self addSubview:_coursePrice];
    //初始化课程售价控件
    
    _numberOfMembersInCourse = [[UILabel alloc]init];
    _numberOfMembersInCourse.textColor = courseGrayColor;
    _numberOfMembersInCourse.font = coursePriceFont;
    [self addSubview:_numberOfMembersInCourse];
    //初始化上课人数
    
    _splitLine = [[UIView alloc]init];
    _splitLine.backgroundColor = courseGrayColor;
    [self addSubview:_splitLine];
    
    
}

-(void) setCourse:(ObjectOfCourse *) course {
    [_coursePhoto mas_makeConstraints:^(MASConstraintMaker *make){
        make.top.equalTo(self).with.offset(13);
        make.bottom.equalTo(self).with.offset(-13);
        make.leading.equalTo(self).with.offset(11);
        make.width.equalTo(self).with.multipliedBy(0.3).offset(0);
        make.height.equalTo(_coursePhoto.mas_width).with.multipliedBy(0.75).offset(0);
        //设置课程图片布局约束
        _coursePhoto.image = [UIImage imageNamed:course.coursePhotoPath];
    }];
    
    [_courseDescribtion mas_makeConstraints:^(MASConstraintMaker *make){
        make.top.equalTo(self).with.offset(13);
        make.leading.equalTo(_coursePhoto.mas_trailing).with.offset(11);
        make.trailing.equalTo(self).with.offset(-15);
        //设置课程描述标题布局约束
        _courseDescribtion.text = course.courseDescribtion;
    }];
    
    [_courseTeacher mas_makeConstraints:^(MASConstraintMaker *make){
        make.top.equalTo(_courseDescribtion.mas_bottom).with.offset(3);
        make.leading.equalTo(_coursePhoto.mas_trailing).with.offset(11);
        //设置课程老师布局约束
        _courseTeacher.text = course.courseTeacher;
    }];
    
    [_splitLine mas_makeConstraints:^(MASConstraintMaker *make){
        make.top.equalTo(_courseDescribtion.mas_bottom).with.offset(3);
        make.leading.equalTo(_courseTeacher.mas_trailing).with.offset(8);
        make.width.mas_equalTo(@1);
        make.height.equalTo(_courseTeacher.mas_height);
        //设置课程老师和上课日期中间的分割线
    }];
    
    [_courseDate mas_makeConstraints:^(MASConstraintMaker *make){
        make.top.equalTo(_courseDescribtion.mas_bottom).with.offset(3);
        make.leading.equalTo(_splitLine.mas_trailing).with.offset(8);
        //设置上课日期的布局约束
        _courseDate.text = course.courseDate;
    }];
    
    [_coursePrice mas_makeConstraints:^(MASConstraintMaker *make){
        make.top.equalTo(_courseTeacher.mas_bottom).with.offset(3);
        make.leading.equalTo(_coursePhoto.mas_trailing).with.offset(11);
        //设置课程售价的布局约束
        _coursePrice.text = course.coursePrice;
    }];
    
    [_numberOfMembersInCourse mas_makeConstraints:^(MASConstraintMaker *make){
        make.top.equalTo(_courseDate.mas_bottom).with.offset(3);
        make.leading.equalTo(_coursePrice.mas_trailing).with.offset(8);
        //设置报名人数的布局约束
        _numberOfMembersInCourse.text = course.numberOfMembersInCourse;
    }];
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
