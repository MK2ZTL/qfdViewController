//
//  courses.m
//  LauncherInterface
//
//  Created by Apple on 16/7/4.
//  Copyright © 2016年 MK2. All rights reserved.
//

#import "courses.h"
#import "ObjectOfCourse.h"
#import "describtionOfCourseCell.h"
#define cWidthOfScreen [[UIScreen mainScreen] bounds].size.width
#define cHeightOfScreen [[UIScreen mainScreen] bounds].size.width * 9/16

@interface courses()

@property (nonatomic) NSMutableArray *course;

@end

@implementation courses

#pragma mark 工厂方法
+(courses *) courses{
    courses *course = [[courses alloc]initCourses];
    return course;
}

#pragma mark 初始化方法
-(courses *) initCourses{
    if (self=[super init]) {
    [self initData];
        self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0,cHeightOfScreen+360,cWidthOfScreen,300)];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    }
    return self;
}

#pragma mark 加载数据

-(void) initData{
    NSString *courseObjectPath = [[NSBundle mainBundle] pathForResource:@"courseRecommendation" ofType:@"plist"];
    NSArray *courseObjectArray = [NSArray arrayWithContentsOfFile:courseObjectPath];
    //根据plist文件，获取课程对象数组
    
    self.course = [[NSMutableArray alloc]init];
    [courseObjectArray enumerateObjectsUsingBlock:^(NSDictionary *obj, NSUInteger idx, BOOL *stop) {
        [self.course addObject:[ObjectOfCourse courseWithDictionary:obj]];
    }];
    //遍历课程对象数组，赋给对应的self.course
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.course.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"describtionOfCourseCellKey";
    describtionOfCourseCell *cell;
    cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(!cell){
        cell = [[describtionOfCourseCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    ObjectOfCourse *course=self.course[indexPath.row];
    cell.course = course;
    
    return cell;
}

-(CGFloat) tableView:(UITableView *) tableView heightForRowAtIndexPath:(NSIndexPath *) indexPath {
    return 90;
}
@end
