//
//  ObjectOfCourse.h
//  LauncherInterface
//
//  Created by Apple on 16/6/28.
//  Copyright © 2016年 MK2. All rights reserved.
//

//通过plist文件生成课程对象

#import <Foundation/Foundation.h>

@interface ObjectOfCourse : NSObject

#pragma mark - 属性
@property (nonatomic,copy) NSString *coursePhotoPath;
//课程介绍图片的路径
@property (nonatomic,copy) NSString *courseDescribtion;
//课程描述
@property (nonatomic,copy) NSString *courseTeacher;
//课程老师
@property (nonatomic,copy) NSString *courseDate;
//上课时间
@property (nonatomic,copy) NSString *coursePrice;
//课程售价
@property (nonatomic,copy) NSString *numberOfMembersInCourse;
//报名人数

#pragma mark - 方法
#pragma mark 根据字典初始化课程对象
-(ObjectOfCourse *) initWithDictionary:(NSDictionary *) dic;

#pragma mark - 初始化课程对象（工厂方法）
+(ObjectOfCourse *) courseWithDictionary:(NSDictionary *) dic;

@end
