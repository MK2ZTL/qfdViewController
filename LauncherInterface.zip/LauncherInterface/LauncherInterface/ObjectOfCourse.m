//
//  ObjectOfCourse.m
//  LauncherInterface
//
//  Created by Apple on 16/6/28.
//  Copyright © 2016年 MK2. All rights reserved.
//



#import "ObjectOfCourse.h"

@implementation ObjectOfCourse

#pragma mark 根据字典初始化课程对象
-(ObjectOfCourse *) initWithDictionary:(NSDictionary *)dic {
    if(self=[super init]){
        self.coursePhotoPath = dic[@"coursePhotoPath"];
        self.courseDescribtion = dic[@"courseDescribtion"];
        self.courseTeacher = dic[@"courseTeacher"];
        self.courseDate = dic[@"courseDate"];
        self.coursePrice = dic[@"coursePrice"];
        self.numberOfMembersInCourse = dic[@"numberOfMembersInCourse"];
    }
    return self;
}

#pragma mark 初始化课程对象（工厂方法）
+(ObjectOfCourse *) courseWithDictionary:(NSDictionary *)dic {
    ObjectOfCourse *course = [[ObjectOfCourse alloc] initWithDictionary:dic];
    return course;
}

@end
