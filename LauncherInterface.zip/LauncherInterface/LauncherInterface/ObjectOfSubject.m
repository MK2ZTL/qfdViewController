//
//  ObjectOfSubject.m
//  LauncherInterface
//
//  Created by Apple on 16/7/2.
//  Copyright © 2016年 MK2. All rights reserved.
//

#import "ObjectOfSubject.h"

@implementation ObjectOfSubject

#pragma mark 根据字典初始化科目对象
-(ObjectOfSubject *) initWithDictionary:(NSDictionary *)dic {
    if(self=[super init]){
        self.SubjectPhotoPath = dic[@"SubjectPhotoPath"];
        self.SubjectDescribtion = dic[@"SubjectDescribtion"];
    }
    return self;
}

#pragma mark 初始化课程对象（工厂方法）
+(ObjectOfSubject *) SubjectWithDictionary:(NSDictionary *)dic {
    ObjectOfSubject *Subject = [[ObjectOfSubject alloc] initWithDictionary:dic];
    return Subject;
}

@end
