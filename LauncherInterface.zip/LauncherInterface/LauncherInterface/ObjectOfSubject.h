//
//  ObjectOfSubject.h
//  LauncherInterface
//
//  Created by Apple on 16/7/2.
//  Copyright © 2016年 MK2. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ObjectOfSubject : NSObject

#pragma mark - 属性
@property (nonatomic,copy) NSString *SubjectPhotoPath;
//科目图片的路径
@property (nonatomic,copy) NSString *SubjectDescribtion;
//科目描述

#pragma mark - 方法
#pragma mark 根据字典初始化科目对象
-(ObjectOfSubject *) initWithDictionary:(NSDictionary *) dic;

#pragma mark - 初始化科目对象（工厂方法）
+(ObjectOfSubject *) SubjectWithDictionary:(NSDictionary *) dic;

@end
