//
//  describtionOfCourseCell.h
//  LauncherInterface
//
//  Created by Apple on 16/6/28.
//  Copyright © 2016年 MK2. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ObjectOfCourse;

@interface describtionOfCourseCell : UITableViewCell

#pragma mark 课程对象
@property (nonatomic,strong) ObjectOfCourse *course;

@end
