//
//  Subject.h
//  LauncherInterface
//
//  Created by Apple on 16/7/4.
//  Copyright © 2016年 MK2. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Subject : NSObject

@property (nonatomic) UICollectionView *collectionView;

+(Subject *) subject;
//初始化科目视图的工厂方法
-(Subject *) initFrame;
//科目视图的初始化方法

@end
