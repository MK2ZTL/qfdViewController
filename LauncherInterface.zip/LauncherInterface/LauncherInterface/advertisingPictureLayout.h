//
//  advertisingPictureLayout.h
//  LauncherInterface
//
//  Created by Apple on 16/7/4.
//  Copyright © 2016年 MK2. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface advertisingPictureLayout : NSObject

@property (nonatomic) UIScrollView *scrV;
@property (nonatomic) UIPageControl *pageC;
@property (nonatomic) NSUInteger imageCount;

+(advertisingPictureLayout *) advertisingPicture;
//初始化视图控件的工厂方法

-(advertisingPictureLayout *) initFrame;
//初始化视图控件

@end
