//
//  describtionOfSubjectCell.m
//  LauncherInterface
//
//  Created by Apple on 16/7/2.
//  Copyright © 2016年 MK2. All rights reserved.
//

#import "describtionOfSubjectCell.h"
#import "Masonry.h"
//导入masonry头文件
#import "ObjectOfSubject.h"
//导入科目对象头文件

#define SubjectCollectionViewCellBackgroundColor [UIColor whiteColor]
#define SubjectBlackColor [UIColor blackColor]
#define SubjectGrayColor [UIColor grayColor]

#define SubjectBoldFont [UIFont boldSystemFontOfSize:11]
#define SubjectDefaultFont [UIFont fontWithName:@"ArialMT" size:9]

@implementation describtionOfSubjectCell

-(instancetype)initWithFrame:(CGRect) frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self initSubView];
    }
    return self;
}

#pragma mark 初始化视图控件
-(void) initSubView{
    
    self.SubjectPhoto = [[UIImageView alloc] init];
    self.SubjectPhoto.contentMode = UIViewContentModeScaleAspectFit;
    [self.contentView addSubview:_SubjectPhoto];
    //初始化科目图片控件
    
    self.SubjectDescribtion = [[UILabel alloc]init];
    self.SubjectDescribtion.textColor = SubjectBlackColor;
    self.SubjectDescribtion.font = SubjectBoldFont;
    self.SubjectDescribtion.numberOfLines = 0;
    [self.contentView addSubview:self.SubjectDescribtion];
    //初始化科目描述控件
    
}

-(void) setSubject:(ObjectOfSubject *) Subject {
    [self.SubjectPhoto mas_makeConstraints:^(MASConstraintMaker *make){
        
        make.top.equalTo(self.contentView).with.offset(0);
        make.leading.equalTo(self.contentView).with.offset(0);
        make.trailing.equalTo(self.contentView).with.offset(0);
        
        make.height.equalTo(self.contentView);
        make.width.equalTo(self.SubjectPhoto.mas_height);
        //设置科目图片布局约束
        self.SubjectPhoto.image = [UIImage imageNamed:Subject.SubjectPhotoPath];
    }];
    
    [self.SubjectDescribtion mas_makeConstraints:^(MASConstraintMaker *make){
        make.top.equalTo(self.SubjectPhoto.mas_bottom).with.offset(5);
        
        make.width.equalTo(self.contentView);
        //设置科目描述标题布局约束
        self.SubjectDescribtion.text = Subject.SubjectDescribtion;
        self.SubjectDescribtion.textAlignment = NSTextAlignmentCenter;
    }];
}
@end
