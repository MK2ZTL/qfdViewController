//
//  courses.h
//  LauncherInterface
//
//  Created by Apple on 16/7/4.
//  Copyright © 2016年 MK2. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface courses : NSObject

@property (nonatomic) UITableView *tableView;

+(courses *) courses;
//初始化主题视图的工厂方法
-(courses *) initCourses;
//主题视图的初始化方法

@end
