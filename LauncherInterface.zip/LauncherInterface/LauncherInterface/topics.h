//
//  topics.h
//  LauncherInterface
//
//  Created by Apple on 16/7/4.
//  Copyright © 2016年 MK2. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface topics : NSObject

@property (nonatomic) UICollectionView *collectionView;

+(topics *) topics;
//初始化主题视图的工厂方法
-(topics *) initFrame;
//主题视图的初始化方法

@end
