//
//  describtionOfTopicCellCollectionViewCell.h
//  LauncherInterface
//
//  Created by Apple on 16/6/30.
//  Copyright © 2016年 MK2. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ObjectOfTopic;

@interface describtionOfTopicCell : UICollectionViewCell

#pragma mark 主题对象
@property (nonatomic,strong) ObjectOfTopic *topic;

@property (nonatomic) UIImageView *topicPhoto;
@property (nonatomic) UILabel *topicDescribtion;
@property (nonatomic) UILabel *topicSubtitle;
//主题表单元格的3个UI对象

@end
