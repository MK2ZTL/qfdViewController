//
//  ViewController.m
//  LauncherInterface
//
//  Created by Apple on 16/7/4.
//  Copyright © 2016年 MK2. All rights reserved.
//

#import "qfdViewController.h"
#import "masonry.h"
#define cWidthOfScreen [[UIScreen mainScreen] bounds].size.width

@interface qfdViewController ()

@property (nonatomic) UILabel *firstPage;
//首页栏目
@property (nonatomic) UIView *splitView1;
//第一条分割线

@property (nonatomic) UIView *topicBackground1;
@property (nonatomic) UIView *orangeColor;
@property (nonatomic) UILabel *specialTopic;
//精选专题栏目

@property (nonatomic) UIView *splitView2;
//第二条分割线

@property (nonatomic) UIView *topicBackground2;
@property (nonatomic) UIView *orangeColor1;
@property (nonatomic) UILabel *specialTopic1;
//精选专题栏目

-(void)addScrollView;
-(void)initSubView;
-(void)layoutSubView;

@end

@implementation qfdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self addScrollView];
    //添加主滚动视图
    [self initSubView];
    //初始化滚动视图内各内容视图
    [self layoutSubView];
    //对各内容视图布局约束

    // Do any additional setup after loading the view.
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)addScrollView {
    self.mainScrV = [[UIScrollView alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.mainScrV.scrollEnabled = YES;
    self.mainScrV.userInteractionEnabled = YES;
    self.mainScrV.contentSize = CGSizeMake(cWidthOfScreen, 1000);
    [self.view addSubview:self.mainScrV];
    self.mainScrV.delegate = self;
    //添加主滚动视图
}

-(void)initSubView {
    
    self.firstPage = [[UILabel alloc] init];
    self.firstPage.text = @"首页";
    self.firstPage.textAlignment = NSTextAlignmentCenter;
    self.firstPage.font = [UIFont boldSystemFontOfSize:(15)];
    [self.view addSubview:self.firstPage];
    //初始化首页栏目
    
    self.advertice = [advertisingPictureLayout advertisingPicture];
    [self.mainScrV addSubview:self.advertice.scrV];
    [self.mainScrV addSubview:self.advertice.pageC];
    //初始化滚动广告视图
    
    self.subject = [Subject subject];
    [self.mainScrV addSubview:self.subject.collectionView];
    //初始化科目视图
    
    self.splitView1 = [[UIView alloc]init];
    self.splitView1.backgroundColor = [UIColor grayColor];
    [self.mainScrV addSubview:self.splitView1];
    //初始化第一个分割view
    
    self.topicBackground1 = [[UIView alloc]init];
    [self.mainScrV addSubview:self.topicBackground1];
    
    self.orangeColor = [[UIView alloc]init];
    self.orangeColor.backgroundColor = [UIColor orangeColor];
    [self.topicBackground1 addSubview:self.orangeColor];

    self.specialTopic = [[UILabel alloc]init];
    self.specialTopic.text = @"精选专题";
    self.specialTopic.font = [UIFont fontWithName:@"ArialMT" size:12];
    [self.topicBackground1 addSubview:self.specialTopic];
    //初始化精选专题栏目
    
    self.topics = [topics topics];
    [self.mainScrV addSubview:self.topics.collectionView];
    //初始化主题视图
    
    self.splitView2 = [[UIView alloc]init];
    self.splitView2.backgroundColor = [UIColor grayColor];
    [self.mainScrV addSubview:self.splitView2];
    //初始化第二个分割view
    
    self.topicBackground2 = [[UIView alloc]init];
    [self.mainScrV addSubview:self.topicBackground2];
    
    self.orangeColor1 = [[UIView alloc]init];
    self.orangeColor1.backgroundColor = [UIColor orangeColor];
    [self.topicBackground2 addSubview:self.orangeColor1];
    
    self.specialTopic1 = [[UILabel alloc]init];
    self.specialTopic1.text = @"为您推荐";
    self.specialTopic1.font = [UIFont fontWithName:@"ArialMT" size:12];
    [self.topicBackground2 addSubview:self.specialTopic1];
    //初始化精选专题栏目
    
    self.courses = [courses courses];
    [self.mainScrV addSubview:self.courses.tableView];
}

-(void)layoutSubView {
    
    [self.firstPage mas_makeConstraints:^(MASConstraintMaker *make){
        make.top.equalTo(self.mainScrV).with.offset(20);
        make.leading.equalTo(self.mainScrV);
        make.trailing.equalTo(self.mainScrV);
        make.width.equalTo(self.mainScrV);
        make.height.mas_equalTo(40);
    }];
    //设置首页栏目布局约束
    
    [self.splitView1 mas_makeConstraints:^(MASConstraintMaker *make){
        
        
        make.top.equalTo(self.subject.collectionView.mas_bottom).with.offset(10);
        make.leading.equalTo(self.mainScrV).with.offset(0);
        make.trailing.equalTo(self.mainScrV).with.offset(0);
        make.height.mas_equalTo(10);
        make.width.equalTo(self.mainScrV);

    }];
    //设置第一条分割线布局约束
    
    [self.topicBackground1 mas_makeConstraints:^(MASConstraintMaker *make){
        make.top.equalTo(self.splitView1.mas_bottom).with.offset(0);
        make.leading.equalTo(self.mainScrV).with.offset(0);
        make.trailing.equalTo(self.mainScrV).with.offset(0);
        make.height.mas_equalTo(35);
        make.width.equalTo(self.mainScrV);
    }];
    
    [self.orangeColor mas_makeConstraints:^(MASConstraintMaker *make){
        make.leading.equalTo(self.topicBackground1).with.offset(10);
        make.top.equalTo(self.topicBackground1).with.offset(10);
        make.bottom.equalTo(self.topicBackground1).with.offset(-10);
        make.width.mas_equalTo(4);
        make.height.mas_equalTo(15);
    }];
    
    [self.specialTopic mas_makeConstraints:^(MASConstraintMaker *make){
        make.leading.equalTo(self.orangeColor.mas_trailing).with.offset(10);
        make.top.equalTo(self.topicBackground1).with.offset(10);
        make.bottom.equalTo(self.topicBackground1).with.offset(-10);
        make.height.mas_equalTo(15);
    }];
    //精选专题栏目布局约束
    
    [self.splitView2 mas_makeConstraints:^(MASConstraintMaker *make){
        
        
        make.top.equalTo(self.topics.collectionView.mas_bottom).with.offset(10);
        make.leading.equalTo(self.mainScrV).with.offset(0);
        make.trailing.equalTo(self.mainScrV).with.offset(0);
        make.height.mas_equalTo(10);
        make.width.equalTo(self.mainScrV);
        
    }];
    //设置第二条分割线布局约束
    
    [self.topicBackground2 mas_makeConstraints:^(MASConstraintMaker *make){
        make.top.equalTo(self.splitView2.mas_bottom).with.offset(0);
        make.leading.equalTo(self.mainScrV).with.offset(0);
        make.trailing.equalTo(self.mainScrV).with.offset(0);
        make.height.mas_equalTo(35);
        make.width.equalTo(self.mainScrV);
    }];
    
    [self.orangeColor1 mas_makeConstraints:^(MASConstraintMaker *make){
        make.leading.equalTo(self.topicBackground2).with.offset(10);
        make.top.equalTo(self.topicBackground2).with.offset(10);
        make.bottom.equalTo(self.topicBackground2).with.offset(-10);
        make.width.mas_equalTo(4);
        make.height.mas_equalTo(15);
    }];
    
    [self.specialTopic1 mas_makeConstraints:^(MASConstraintMaker *make){
        make.leading.equalTo(self.orangeColor1.mas_trailing).with.offset(10);
        make.top.equalTo(self.topicBackground2).with.offset(10);
        make.bottom.equalTo(self.topicBackground2).with.offset(-10);
        make.height.mas_equalTo(15);
    }];
    //精选专题栏目布局约束
}

@end
